package util;

public class XLException extends RuntimeException {
    public XLException(String message) {
        super(message);
    }
}